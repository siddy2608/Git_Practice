/**
 * Finnova M-RAL Prototype - Centralized Navigation & Module Registry
 * Sprint 1 Base UI Foundation
 * 
 * Central registry for all 14 project-to-cash modules.
 * Architecture Note for 12-developer team:
 * To add a new module in Sprint 2+:
 *   1. Create `modules/<module-id>/index.html`
 *   2. Update the `path` and `status` in MODULE_REGISTRY below
 *   3. The master layout automatically loads your page without modifying HTML or header!
 */

(function () {
  const MODULE_REGISTRY = [
    {
      id: "overview",
      title: "Overview & Liquidity Pulse",
      shortTitle: "Overview",
      category: "Executive Suite",
      path: "modules/overview/index.html",
      status: "ready",
      badgeText: "Ready",
      badgeClass: "badge-ready",
      description: "Executive KPIs, milestone pipeline, cash runway summary, and recent project-to-cash activity.",
      icon: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="9"></rect><rect x="14" y="3" width="7" height="5"></rect><rect x="14" y="12" width="7" height="9"></rect><rect x="3" y="16" width="7" height="5"></rect></svg>`
    },
    {
      id: "access",
      title: "Access Management",
      shortTitle: "Access Management",
      category: "Governance",
      path: "modules/placeholder/index.html?module=access",
      status: "pending",
      badgeText: "Sprint 2",
      badgeClass: "badge-sprint",
      description: "User roles, permissions matrix, client portal user provisioning, and authorization audit logs.",
      icon: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path></svg>`
    },
    {
      id: "commercial",
      title: "Commercial Management",
      shortTitle: "Commercial Management",
      category: "Project Operations",
      path: "modules/placeholder/index.html?module=commercial",
      status: "pending",
      badgeText: "Sprint 2",
      badgeClass: "badge-sprint",
      description: "Client contracts, statements of work (SOW), master service agreements, and commercial billing terms.",
      icon: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>`
    },
    {
      id: "projects",
      title: "Project Management",
      shortTitle: "Project Management",
      category: "Project Operations",
      path: "modules/placeholder/index.html?module=projects",
      status: "pending",
      badgeText: "Sprint 2",
      badgeClass: "badge-sprint",
      description: "Project setup, scope breakdown, budget baselines, client stakeholders, and milestone schedules.",
      icon: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 2 7 12 12 22 7 12 2"></polygon><polyline points="2 17 12 22 22 17"></polyline><polyline points="2 12 12 17 22 12"></polyline></svg>`
    },
    {
      id: "delivery",
      title: "Delivery Management",
      shortTitle: "Delivery Management",
      category: "Project Operations",
      path: "modules/placeholder/index.html?module=delivery",
      status: "pending",
      badgeText: "Sprint 2",
      badgeClass: "badge-sprint",
      description: "Sprint delivery tracking, milestone completion evidence, technical work packages, and sign-off criteria.",
      icon: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 11 12 14 22 4"></polyline><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path></svg>`
    },
    {
      id: "risk",
      title: "Project Risk Management",
      shortTitle: "Project Risk",
      category: "Project Operations",
      path: "modules/placeholder/index.html?module=risk",
      status: "pending",
      badgeText: "Sprint 2",
      badgeClass: "badge-sprint",
      description: "Delivery risk register, mitigation plans, milestone slippage risk, and financial impact scoring.",
      icon: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>`
    },
    {
      id: "acceptance",
      title: "Milestone Acceptance",
      shortTitle: "Milestone Acceptance",
      category: "Project Operations",
      path: "modules/placeholder/index.html?module=acceptance",
      status: "pending",
      badgeText: "Sprint 2",
      badgeClass: "badge-sprint",
      description: "Client acceptance gateway, sign-off certificates, rejection dispute workflows, and readiness checklists.",
      icon: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>`
    },
    {
      id: "project-to-cash",
      title: "Project-to-Cash Lifecycle",
      shortTitle: "Project-to-Cash",
      category: "Financial Engine",
      path: "modules/placeholder/index.html?module=project-to-cash",
      status: "pending",
      badgeText: "Sprint 2",
      badgeClass: "badge-sprint",
      description: "End-to-end pipeline visibility from milestone delivery to bank cash realization and revenue recognition.",
      icon: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>`
    },
    {
      id: "billing",
      title: "Billing Management",
      shortTitle: "Billing Management",
      category: "Financial Engine",
      path: "modules/placeholder/index.html?module=billing",
      status: "pending",
      badgeText: "Sprint 2",
      badgeClass: "badge-sprint",
      description: "Accepted milestone billing triggers, billing schedules, unbilled revenue aging, and draft generation.",
      icon: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="1" y="4" width="22" height="16" rx="2" ry="2"></rect><line x1="1" y1="10" x2="23" y2="10"></line></svg>`
    },
    {
      id: "invoices",
      title: "Invoice Management",
      shortTitle: "Invoice Management",
      category: "Financial Engine",
      path: "modules/placeholder/index.html?module=invoices",
      status: "pending",
      badgeText: "Sprint 2",
      badgeClass: "badge-sprint",
      description: "Tax invoice issuance, client delivery dispatch, PDF generation, credit notes, and invoice lifecycle.",
      icon: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="12" y1="18" x2="12" y2="12"></line><line x1="9" y1="15" x2="15" y2="15"></line></svg>`
    },
    {
      id: "collections",
      title: "Collections Management",
      shortTitle: "Collections Management",
      category: "Treasury & Capital",
      path: "modules/placeholder/index.html?module=collections",
      status: "pending",
      badgeText: "Sprint 2",
      badgeClass: "badge-sprint",
      description: "Accounts receivable aging, dunning notices, client payment tracking, and disputes resolution.",
      icon: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><path d="M16 8h-6a2 2 0 1 0 0 4h4a2 2 0 1 1 0 4H8"></path><line x1="12" y1="6" x2="12" y2="8"></line><line x1="12" y1="16" x2="12" y2="18"></line></svg>`
    },
    {
      id: "payments",
      title: "Payments Management",
      shortTitle: "Payments Management",
      category: "Treasury & Capital",
      path: "modules/placeholder/index.html?module=payments",
      status: "pending",
      badgeText: "Sprint 2",
      badgeClass: "badge-sprint",
      description: "Inbound cash receipts, bank statement reconciliation, automated invoice matching, and remittance advice.",
      icon: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="5" width="20" height="14" rx="2"></rect><line x1="2" y1="10" x2="22" y2="10"></line></svg>`
    },
    {
      id: "working-capital",
      title: "Working Capital Health",
      shortTitle: "Working Capital",
      category: "Treasury & Capital",
      path: "modules/placeholder/index.html?module=working-capital",
      status: "pending",
      badgeText: "Sprint 2",
      badgeClass: "badge-sprint",
      description: "DSO, DPO, CCC working capital metrics, cash conversion cycle optimization, and balance sheet indicators.",
      icon: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="20" x2="18" y2="10"></line><line x1="12" y1="20" x2="12" y2="4"></line><line x1="6" y1="20" x2="6" y2="14"></line></svg>`
    },
    {
      id: "liquidity",
      title: "Liquidity Management & Forecasting",
      shortTitle: "Liquidity Management",
      category: "Treasury & Capital",
      path: "modules/placeholder/index.html?module=liquidity",
      status: "pending",
      badgeText: "Sprint 2",
      badgeClass: "badge-sprint",
      description: "13-week cash forecasting, funding gap sensitivity models, scenario simulations, and treasury buffer alerts.",
      icon: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21.21 15.89A10 10 0 1 1 8 2.83"></path><path d="M22 12A10 10 0 0 0 12 2v10z"></path></svg>`
    }
  ];

  const Navigation = {
    modules: MODULE_REGISTRY,
    currentModuleId: "overview",

    /**
     * Get module definition by ID
     */
    getModule(id) {
      return this.modules.find((m) => m.id === id) || this.modules[0];
    },

    /**
     * Render the persistent sidebar navigation grouped by category
     */
    renderSidebarNav(containerEl) {
      if (!containerEl) return;

      // Group modules by category
      const categories = {};
      this.modules.forEach((mod) => {
        const cat = mod.category || "General";
        if (!categories[cat]) categories[cat] = [];
        categories[cat].push(mod);
      });

      let html = "";
      Object.keys(categories).forEach((catName) => {
        html += `<div class="nav-section-title">${catName}</div>`;
        html += `<ul class="sidebar-nav-list">`;
        categories[catName].forEach((mod) => {
          const isActive = mod.id === this.currentModuleId;
          html += `
            <li class="sidebar-nav-item">
              <a href="#${mod.id}" 
                 class="sidebar-nav-link ${isActive ? "active" : ""}" 
                 data-module-id="${mod.id}"
                 data-title="${mod.title}"
                 title="${mod.title}">
                <span class="sidebar-nav-icon">${mod.icon}</span>
                <span class="sidebar-nav-label">${mod.shortTitle}</span>
              </a>
            </li>
          `;
        });
        html += `</ul>`;
      });

      containerEl.innerHTML = html;

      // Attach click events
      const links = containerEl.querySelectorAll(".sidebar-nav-link");
      links.forEach((link) => {
        link.addEventListener("click", (e) => {
          e.preventDefault();
          const modId = link.getAttribute("data-module-id");
          this.navigateTo(modId);
        });
      });
    },

    /**
     * Navigate to a module by ID
     */
    navigateTo(moduleId, updateHash = true) {
      const mod = this.getModule(moduleId);
      this.currentModuleId = mod.id;

      // 1. Update active styling in sidebar
      const navLinks = document.querySelectorAll(".sidebar-nav-link");
      navLinks.forEach((link) => {
        if (link.getAttribute("data-module-id") === mod.id) {
          link.classList.add("active");
        } else {
          link.classList.remove("active");
        }
      });

      // 2. Update Header Title & Breadcrumbs
      const headerTitleEl = document.getElementById("header-current-title");
      if (headerTitleEl) {
        headerTitleEl.textContent = mod.title;
      }

      const breadcrumbModuleEl = document.getElementById("breadcrumb-current-module");
      if (breadcrumbModuleEl) {
        breadcrumbModuleEl.textContent = mod.shortTitle;
      }

      // 3. Update Iframe Destination
      const frameEl = document.getElementById("module-frame");
      const overlayEl = document.getElementById("iframe-loader");

      if (frameEl) {
        if (overlayEl) overlayEl.classList.add("active");

        frameEl.onload = () => {
          if (overlayEl) overlayEl.classList.remove("active");
        };

        // Fallback timeout to guarantee loader removal
        setTimeout(() => {
          if (overlayEl) overlayEl.classList.remove("active");
        }, 600);

        // Set iframe source with cache-buster parameter to ensure immediate rendering in enterprise environments
        const cacheBuster = (mod.path.includes("?") ? "&" : "?") + "v=" + Date.now();
        frameEl.src = mod.path + cacheBuster;
      }

      // 4. Update browser hash if requested
      if (updateHash) {
        window.location.hash = mod.id;
      }

      // 5. Close mobile drawer if open
      if (document.body.classList.contains("sidebar-mobile-open")) {
        document.body.classList.remove("sidebar-mobile-open");
      }
    },

    /**
     * Initialize navigation from URL hash on first load
     */
    initFromHash() {
      const hash = window.location.hash.replace("#", "").trim();
      if (hash && this.getModule(hash)) {
        this.navigateTo(hash, false);
      } else {
        this.navigateTo("overview", false);
      }

      // Listen for browser forward/back buttons
      window.addEventListener("hashchange", () => {
        const currentHash = window.location.hash.replace("#", "").trim();
        if (currentHash && currentHash !== this.currentModuleId) {
          this.navigateTo(currentHash, false);
        }
      });
    }
  };

  // Export to window
  window.FinnovaNavigation = Navigation;
})();
