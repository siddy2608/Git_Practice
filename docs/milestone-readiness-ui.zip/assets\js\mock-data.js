/**
 * Finnova M-RAL Prototype - Mock Data & Initial State
 * Sprint 1 Base UI Foundation - Indian Enterprise INR Edition
 * 
 * IMPORTANT: This data is purely synthetic and intended for frontend prototype
 * demonstration only. It must NEVER be used in a production environment.
 */

const FINNOVA_MOCK_DATA = {
  // Pre-seeded Demo Accounts
  users: [
    {
      id: "usr_admin_01",
      email: "admin@finnova.io",
      // Plain text password solely for client-side prototype demonstration
      password: "Admin@1234",
      fullName: "Eleanor Vance",
      organization: "Finnova Advisory Services India Ltd.",
      role: "Administrator",
      status: "Active",
      avatarInitials: "EV",
      createdAt: "2026-01-15T08:00:00Z"
    },
    {
      id: "usr_analyst_02",
      email: "analyst@finnova.io",
      password: "User@1234",
      fullName: "Sophia Chen",
      organization: "Finnova Advisory Services India Ltd.",
      role: "Company User",
      status: "Active",
      avatarInitials: "SC",
      createdAt: "2026-02-01T10:30:00Z"
    },
    {
      id: "usr_pending_03",
      email: "pending.user@clientcorp.com",
      password: "User@1234",
      fullName: "Vikram Malhotra",
      organization: "Tata Digital Enterprises (Mumbai)",
      role: "Pending",
      status: "Pending Approval",
      avatarInitials: "VM",
      createdAt: "2026-03-10T14:15:00Z"
    }
  ],

  // Executive KPI Metrics for Overview Dashboard (Realistic CA / IT Services INR Range)
  kpiMetrics: {
    activeProjects: {
      value: "28 Projects",
      change: "+3 this month",
      trend: "positive",
      subtitle: "₹34.80 Cr Portfolio Contract Value"
    },
    milestonesAwaitingReadiness: {
      value: "14 Milestones",
      change: "4 high-priority",
      trend: "neutral",
      subtitle: "Valued at ₹4.85 Cr across 6 key accounts"
    },
    milestonesAwaitingAcceptance: {
      value: "9 Milestones",
      change: "2 pending > 7 days",
      trend: "negative",
      subtitle: "₹3.12 Cr pending client sign-off"
    },
    acceptedUnbilledValue: {
      value: "₹2.45 Cr",
      change: "Ready to bill",
      trend: "positive",
      subtitle: "Eligible for immediate GST invoice release"
    },
    outstandingReceivables: {
      value: "₹6.82 Cr",
      change: "DSO: 38.5 Days",
      trend: "neutral",
      subtitle: "Weighted average payment term: Net 30"
    },
    overdueInvoices: {
      value: "₹1.18 Cr",
      change: "7 overdue notices",
      trend: "negative",
      subtitle: "2 invoices in 30+ day aging bracket"
    },
    currentCashPosition: {
      value: "₹18.45 Cr",
      change: "+12.4% vs target",
      trend: "positive",
      subtitle: "Primary operating accounts buffer 142%"
    },
    forecastFundingGap: {
      value: "₹0 (Zero Deficit)",
      change: "30-day runway secure",
      trend: "positive",
      subtitle: "Net liquidity cushion of +₹4.15 Cr projected"
    }
  },

  // Milestone Acceptance Pipeline Rows (Indian Corporate Accounts & ₹ Lakh/Crore Range)
  milestonePipeline: [
    {
      code: "PRJ-2026-004",
      project: "Tata Omnichannel Cloud Migration",
      client: "Tata Digital Enterprises (Mumbai)",
      milestone: "M-402: Core Database Cutover & GST Audit",
      value: "₹85,00,000",
      valueINR: 8500000,
      dueDate: "2026-03-28",
      readinessStatus: "Ready",
      readinessBadge: "success",
      acceptanceStatus: "Awaiting Client Sign-Off",
      acceptanceBadge: "warning",
      billingStatus: "Pending Acceptance"
    },
    {
      code: "PRJ-2026-009",
      project: "HDFC Core Banking API Upgrade",
      client: "HDFC Banking Solutions (Mumbai)",
      milestone: "M-301: NEFT/RTGS Clearing Gateway Test",
      value: "₹1,25,00,000",
      valueINR: 12500000,
      dueDate: "2026-03-20",
      readinessStatus: "Ready",
      readinessBadge: "success",
      acceptanceStatus: "Client Accepted",
      acceptanceBadge: "success",
      billingStatus: "Ready to Bill"
    },
    {
      code: "PRJ-2026-012",
      project: "Reliance Supply Chain ERP Integration",
      client: "Reliance Retail Logistics (Navi Mumbai)",
      milestone: "M-204: Automated Customs & E-Way Bill API",
      value: "₹42,00,000",
      valueINR: 4200000,
      dueDate: "2026-04-05",
      readinessStatus: "In Review",
      readinessBadge: "warning",
      acceptanceStatus: "Prerequisites Open",
      acceptanceBadge: "neutral",
      billingStatus: "Unearned"
    },
    {
      code: "PRJ-2026-017",
      project: "Infosys Healthcare Compliance Portal",
      client: "Infosys Health Systems (Bengaluru)",
      milestone: "M-501: DISHA & HIPAA Security Sign-Off",
      value: "₹64,00,000",
      valueINR: 6400000,
      dueDate: "2026-03-15",
      readinessStatus: "Blocked",
      readinessBadge: "danger",
      acceptanceStatus: "Exception Escalated",
      acceptanceBadge: "danger",
      billingStatus: "Hold"
    },
    {
      code: "PRJ-2026-021",
      project: "Mahindra Smart Grid IoT Telemetry",
      client: "Mahindra Power Utilities (Pune)",
      milestone: "M-103: SCADA Integration Pilot",
      value: "₹98,00,000",
      valueINR: 9800000,
      dueDate: "2026-03-24",
      readinessStatus: "Ready",
      readinessBadge: "success",
      acceptanceStatus: "Client Accepted",
      acceptanceBadge: "success",
      billingStatus: "Ready to Bill"
    }
  ],

  // Recent Activity Feed
  recentActivity: [
    {
      id: "act-1",
      type: "acceptance",
      title: "Client Acceptance Signed",
      desc: "HDFC Banking Solutions signed off Milestone M-301 (₹1.25 Cr). Ready for billing release.",
      timestamp: "24 mins ago",
      badge: "success"
    },
    {
      id: "act-2",
      type: "readiness",
      title: "Readiness Gateway Cleared",
      desc: "Tata Digital M-402 passed Delivery Readiness review.",
      timestamp: "1 hour ago",
      badge: "info"
    },
    {
      id: "act-3",
      type: "collection",
      title: "Cash Receipt Reconciled",
      desc: "RTGS transfer of ₹68.0 L matched against INV-2026-048 (Mahindra Power).",
      timestamp: "3 hours ago",
      badge: "success"
    },
    {
      id: "act-4",
      type: "risk",
      title: "Acceptance Dispute Logged",
      desc: "Milestone M-501 flagged for clause 8.2 audit requirement clarification.",
      timestamp: "Yesterday at 16:40",
      badge: "danger"
    }
  ],

  // Mock Notifications for Header Bell
  notifications: [
    {
      id: "notif-1",
      title: "Milestone Acceptance Completed",
      desc: "HDFC Banking Solutions accepted Milestone M-301 (₹1.25 Cr). Billing unlocked.",
      time: "24m ago",
      unread: true,
      type: "success"
    },
    {
      id: "notif-2",
      title: "GST Invoice Approaching Due Date",
      desc: "INV-2026-081 (₹34.0 L) for Reliance Retail is due in 48 hours.",
      time: "2h ago",
      unread: true,
      type: "warning"
    },
    {
      id: "notif-3",
      title: "30-Day Liquidity Forecast Updated",
      desc: "Treasury projection shows operating headroom above ₹18.45 Cr baseline.",
      time: "5h ago",
      unread: true,
      type: "info"
    }
  ]
};

// Export to window for vanilla JS access
window.FINNOVA_MOCK_DATA = FINNOVA_MOCK_DATA;
