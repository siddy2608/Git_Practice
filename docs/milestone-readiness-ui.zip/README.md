# Milestone Readiness, Acceptance & Liquidity Management System (Finnova M-RAL)

> **Sprint 1 Base UI Architecture & Master Foundation**  
> Built with HTML5, CSS3, and Vanilla JavaScript.

---

## 1. Project Overview

The **Milestone Readiness, Acceptance & Liquidity Management System** is an enterprise-grade financial governance platform that coordinates the end-to-end **project-to-cash lifecycle**:
- **Commercial Agreements & Statement of Work (SOW)** setup
- **Sprint & Milestone Delivery Tracking**
- **Delivery Readiness Gate Verifications**
- **Formal Client Acceptance & Dispute Mitigation**
- **Automated Billing Triggers & Tax Invoice Release**
- **Accounts Receivable, Aging & Collections**
- **Cash Receipts Reconciliation & Working Capital Management**
- **13-Week Liquidity Forecasting & Runway Optimization**

---

## 2. Sprint 1 Implementation Scope

As specified in Sprint 1 guidelines, this release establishes a **reusable, extensible master UI foundation** distributed across a team of approximately 12 frontend developers.

### Implemented Screens & Shell Components:
1. **Login Page (`login.html`)**: Complete authentication form with required-field validation, regex email check, password show/hide toggle, "Remember Me" handling, quick demo auto-fill buttons, and role-boundary enforcement.
2. **Registration Page (`register.html`)**: Public demo registration with real-time password complexity checklist, duplicate email prevention, and default non-privileged role assignment (`Company User`, `Pending Approval`).
3. **Admin Main Dashboard Master Layout (`index.html`)**:
   - Persistent Deep Slate/Navy sidebar with all **14 project-to-cash module groups**.
   - Persistent top header with dynamic breadcrumbs, module title, global search, alerts bell with mock notifications, and administrator user profile menu.
   - Reusable iframe content host (`<iframe id="module-frame">`) for modular loading.
   - Fully developed **Executive Overview (`modules/overview/index.html`)** with 8 high-impact financial KPI cards, project-to-cash lifecycle visual stepper, milestone table, and activity feed.
   - Dynamic **Placeholder Engine (`modules/placeholder/index.html`)** providing developer handoff instructions for all unbuilt modules.

---

## 3. Technology Stack & Design System

- **Core**: HTML5, Vanilla JavaScript (ES6+), and CSS3.
- **Styling**: Pure Vanilla CSS with a structured design token system:
  - `assets/css/base.css`: CSS custom properties (color tokens, typography, spacing, shadows, radii, reset).
  - `assets/css/components.css`: Buttons, form controls, KPI cards, tables, badges, modals, toast alerts.
  - `assets/css/layout.css`: Persistent sidebar, master header, iframe host, notification popover.
  - `assets/css/auth.css`: Fintech split-card layout, quick-fill pills, password checklist.
  - `assets/css/responsive.css`: Breakpoints for desktop, tablet, and mobile off-canvas drawer.
- **Storage**: Browser `localStorage` and `sessionStorage` for prototype data persistence.
- **Dependencies**: **Zero external dependencies, frameworks, or build steps**. Runs directly on any static web server.

---

## 4. Pre-Configured Demo Credentials

The prototype automatically seeds the following demonstration accounts into local browser storage:

| Account Type | Email Address | Password | Role | Access Scope |
| :--- | :--- | :--- | :--- | :--- |
| **System Administrator** | `admin@finnova.io` | `Admin@1234` | `Administrator` | **Full Access** to Admin Main Dashboard & Modules |
| **Standard Company User** | `analyst@finnova.io` | `User@1234` | `Company User` | **Restricted**: Triggers access advisory modal on login |
| **Pending Approval User** | `pending.user@clientcorp.com` | `User@1234` | `Pending` | **Restricted**: Illustrates unapproved account state |

> **Evaluator Tip:** The login screen features one-click **"Quick Demo Credentials"** pills to instantly populate fields.

---

## 5. Security & Prototype Limitations

> [!IMPORTANT]
> **Prototype Safety Notice:**
> - All authentication, session state, and role checks in Sprint 1 are **simulated client-side** using browser storage (`localStorage` & `sessionStorage`).
> - This implementation is **strictly for demonstration and usability testing**. It does **NOT** provide production-grade authentication or data security.
> - **Never store real production passwords, API secrets, confidential commercial agreements, or real financial figures** in this prototype.
> - In production, authentication and authorization must be executed securely on a backend server using HTTPS, salted password hashes (e.g. Argon2/bcrypt), signed JWT tokens/HTTP-only cookies, and server-side RBAC middleware.

---

## 6. How to Run Locally

Because the application uses native ES6 JavaScript and iframe communication, it should be served through a local static HTTP server to prevent local file protocol (`file:///`) security restrictions:

### Option A: VS Code Live Server (Recommended)
1. Open this repository folder in **VS Code**.
2. Right-click [`index.html`](file:///index.html) or [`login.html`](file:///login.html).
3. Select **"Open with Live Server"**.
4. The application will launch at `http://127.0.0.1:5500/login.html`.

### Option B: Python Simple HTTP Server
Open your terminal in the project root directory and run:
```bash
# Python 3
python -m http.server 8080
```
Then navigate your browser to `http://localhost:8080/login.html`.

### Option C: Node.js `serve` or `npx`
```bash
npx serve .
```

---

## 7. Developer Collaboration Guide (Team of 12)

This architecture was designed so 12 developers can build out the remaining modules in parallel without merge conflicts or altering the master layout shell.

### File Ownership & Governance
- **Master Framework Maintainer**:
  - Owns: `index.html`, `login.html`, `register.html`, `assets/css/*`, and `assets/js/{app,auth,storage,permissions,validation}.js`.
- **Module Developers (12 Contributors)**:
  - Own their respective subfolder in `modules/<module-id>/` (e.g., `modules/commercial/index.html`).
  - Only touch `assets/js/navigation.js` to register their new page.

### 3-Step Guide: Adding a New Business Module
To add a new module (e.g., **Commercial Management**):

1. **Create your module HTML file**:
   Inside `modules/commercial/index.html`:
   ```html
   <!DOCTYPE html>
   <html lang="en">
   <head>
     <meta charset="UTF-8">
     <title>Commercial Management | Finnova</title>
     <link rel="stylesheet" href="../../assets/css/base.css">
     <link rel="stylesheet" href="../../assets/css/components.css">
   </head>
   <body>
     <div class="card">
       <div class="card-header"><h3 class="card-title">Commercial Agreements</h3></div>
       <div class="card-body">Your module content here...</div>
     </div>
   </body>
   </html>
   ```
2. **Register in `assets/js/navigation.js`**:
   Find your module entry in `MODULE_REGISTRY` and update its `path` and `status`:
   ```javascript
   {
     id: "commercial",
     title: "Commercial Management",
     shortTitle: "Commercial",
     category: "Project Operations",
     path: "modules/commercial/index.html", // Updated relative path
     status: "ready",                      // Marked as ready
     badgeText: "Ready",
     badgeClass: "badge-ready",
     ...
   }
   ```
3. **Verify in the browser**:
   Click "Commercial Management" in the sidebar — your page will load seamlessly into the master iframe container while preserving the persistent sidebar, header, and user session!

### Recommended Git Workflow
- Create a dedicated feature branch for your module: `git checkout -b feat/module-<module-name>`.
- Use relative paths everywhere.
- Do not add duplicate sidebar or header elements inside module HTML files.

---

## 8. Directory Structure

```text
finnova/
├── index.html                     # Admin Main Dashboard Master Layout (Persistent Shell)
├── login.html                     # Enterprise Login Screen
├── register.html                  # Demo User Registration Screen
├── README.md                      # Architecture & Developer Documentation
│
├── assets/
│   ├── css/
│   │   ├── base.css               # Design tokens, variables, typography, reset
│   │   ├── components.css         # Reusable buttons, cards, KPI metrics, tables, badges
│   │   ├── layout.css             # Persistent sidebar, header, iframe container, popovers
│   │   ├── auth.css               # Fintech auth split-card, demo pills, password checklist
│   │   └── responsive.css         # Responsive drawer sidebar & tablet/mobile breakpoints
│   │
│   └── js/
│       ├── app.js                 # Master shell orchestrator, toasts, modals, header UI
│       ├── auth.js                # Login, registration, session state, route guard
│       ├── navigation.js          # Central registry for all 14 modules & iframe router
│       ├── permissions.js         # Role access boundaries (Administrator vs Company User)
│       ├── storage.js             # Browser storage wrapper, seeding, and demo reset
│       ├── mock-data.js           # Synthetic users, KPIs, pipeline records, notifications
│       └── validation.js          # Form validation engine (email regex, password rules)
│
├── modules/
│   ├── overview/
│   │   └── index.html             # Fully developed Executive Overview & Liquidity Pulse
│   └── placeholder/
│       └── index.html             # Professional fallback & developer handoff for Sprint 2
│
└── client/
    └── README.md                  # Roadmap for future client portal
```

---

## 9. Verification & Acceptance Criteria Checklist

- [x] **Criterion 1**: Login page works and validates required inputs and email format.
- [x] **Criterion 2**: Registration page works, validates fields, and evaluates password strength.
- [x] **Criterion 3**: Registered demo user can log in per prototype rules.
- [x] **Criterion 4**: Duplicate email registrations are rejected.
- [x] **Criterion 5**: Public registration cannot grant administrator privileges (assigns `Company User / Pending Approval`).
- [x] **Criterion 6**: Mock administrator (`admin@finnova.io`) accesses the Admin Main Dashboard.
- [x] **Criterion 7**: Unauthorized or inactive demo users cannot access administrator pages.
- [x] **Criterion 8**: Logout clears the demo session and returns to login.
- [x] **Criterion 9**: Persistent sidebar and top header remain visible when navigation changes.
- [x] **Criterion 10**: Future module links display an informative, professional placeholder.
- [x] **Criterion 11**: Overview displays realistic, clearly labeled illustrative mock data.
- [x] **Criterion 12**: Responsive layout functions on desktop, tablet, and mobile.
- [x] **Criterion 13**: Clean browser console with zero avoidable errors.
- [x] **Criterion 14**: Runs directly on any static web server without build tools.
- [x] **Criterion 15**: README includes setup, demo credentials, limitations, and module guide.
- [x] **Criterion 16**: Packaged into a ZIP archive for team distribution.
